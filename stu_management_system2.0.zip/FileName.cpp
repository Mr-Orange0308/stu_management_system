//#include<iostream> 
//#include<mysql.h>
//#include<vector>
//using namespace std;
//const char* host = "127.0.0.1";
//const char* user = "root";
//const char* psw = "123456";
//const char* database_name = "ship_test";
//const int port = 3306;
////vector<string> queries{
////
////	"create table stu(id INT,name CHAR(20),score INT);",
////		"insert into stu(id,name,score) VALUES('123','TOM','88');"
////		"select * from stu;"
////};
//int main() {
//	MYSQL* con=mysql_init(0);
//	mysql_options(con, MYSQL_SET_CHARSET_NAME, "GBK");
//	if (!mysql_real_connect(con,host,user,psw,database_name,port,NULL,0)) {
//		cout << "����ʧ��" << endl;
//		cout << mysql_error(con) << endl;
//	}
//	/*for (int i = 0; i < queries.size(); i++) {
//		if (!mysql_query(con, queries[i].c_str()) != 0) {
//			cout << "error" << endl;
//			cout << mysql_error(con) << endl;
//		}
//	}*/
//	try {
//		mysql_query(con, "insert into ship01(id,name,age,score) VALUES('123','TOM','99','88');");
//	}
//	catch (exception error) {
//		cout << "����ʧ��" << endl;
//		cout << mysql_error(con) << endl;
//	}
//	//������
//	mysql_query(con, "SELECT * FROM ship01");
//	//ʹ��res�ռ���ѯ��������
//	try {
//		MYSQL_RES* res = mysql_store_result(con);
//		if (!res) {
//			exception error;
//			throw error;
//		}
//		//ȡ���ռ��������ݵ�����(���ڱ���)
//		int num_fields = mysql_num_fields(res);
//		//ȡÿһ�е�����,��ӡ
//		MYSQL_ROW row;
//		while ((row = mysql_fetch_row(res)))
//		{
//			for (int i = 0; i < num_fields; i++)
//			{
//				cout << row[i] << " ";
//			}
//			cout << endl;
//		}
//		mysql_free_result(res);
//	}
//	catch (exception error) {
//		cout << "����ʧ��" << endl;
//	}
//	mysql_query(con, "delete from ship01 where id=123");
//	return 0;
//}
//
////#include <iostream>
////#include<string>
////#include<mysql.h>
////using namespace std;
////
////struct Student
////{
////	int id;
////	string name;
////	int age;
////	double score;
////};
////
////const char* host = "127.0.0.1";
////const char* user = "root";
////const char* psw = "123456";
////const char* database_name = "ship_test";
////const int port = 3306;
////
////class MMSql
////{
////public:
////	MMSql();
////	~MMSql();
////	MYSQL* getConnect();
////	void updateID();
////	void addToMySQL();
////	void delToMySQL();
////	void editToMySQL();
////	void findToMySQL();
////private:
////	MYSQL* con;
////};
////
////MMSql::MMSql()
////{
////	//��ʼ��mysql
////	con = mysql_init(0);
////	//VS�ı��뷽ʽΪGBK,�������MYSQL�ı��뷽ʽΪGBK
////	//�ƺ�û�����Ҳ����
////	mysql_options(con, MYSQL_SET_CHARSET_NAME, "GBK");
////
////	//�������ݿ�
////	if (!mysql_real_connect(con, host, user, psw, database_name, port, NULL, 0))
////	{
////		cout << mysql_error(con) << endl;
////	}
////
////}
////
////MMSql::~MMSql()
////{
////	mysql_close(this->getConnect());
////}
////
////MYSQL* MMSql::getConnect()
////{
////	return this->con;
////}
////
////void MMSql::updateID()
////{
////	/*/ ɾ������������id�ı�� /*/
////	const char* query[] = {
////		//����id�ֶε�ֵ�����´�1��ʼ���
////		//"SET @new_id = 0;",
////		//"UPDATE ship01 SET id = @new_id:=@new_id+1;",
////		////���������������е���СֵΪ1
////		//"ALTER TABLE ship01 AUTO_INCREMENT = 1;"
////		"select * from ship01;",
////		"insert into ship_test (id,name,age,score) VALUES ('2','ABC','20','100');"
////	};
////
////	// ִ�ж���Query���
////	int num_queries = sizeof(query) / sizeof(query[0]);
////	for (int i = 0; i < num_queries; ++i) {
////		if (mysql_query(this->getConnect(), query[i]) != 0) {
////			cout << "ִ��Query���ʧ��: " << mysql_error(this->getConnect()) << endl;
////			return;
////		}
////	}
////}
////
////void MMSql::addToMySQL()
////{
////	Student stu;
////	stu.name = "xiaowang";
////	stu.age = 79;
////	stu.score = 88.9;
////	/*/ ��*/
////		//ͨ��query��������
////	string query = "INSERT INTO ship01 (`name`, age, score) VALUES ('" + stu.name + "', " + to_string(stu.age) + ", " + to_string(stu.score) + ")";
////
////	if (mysql_query(this->getConnect(), query.c_str()) != 0)
////	{
////		cout << mysql_error(this->getConnect()) << endl;
////		mysql_close(this->getConnect());
////		return; // Exit the program with an error code
////	}
////	cout << "���ӳɹ�!" << "��ǰ����Ϊ:" << endl;
////	this->updateID();//��������
////	this->findToMySQL();
////}
////
////void MMSql::delToMySQL()
////{
////	///ɾ
//////ͨ��queryɾ������
////	string query2 = "DELETE FROM ship01 WHERE id=2;";
////	if (mysql_query(this->getConnect(), query2.c_str()) != 0)
////	{
////		cout << mysql_error(this->getConnect()) << endl;
////		mysql_close(this->getConnect());
////		return; // Exit the program with an error code
////	}
////	cout << "ɾ���ɹ�!" << "��ǰ����Ϊ:" << endl;
////	this->updateID();//��������
////	this->findToMySQL();
////}
////
////void MMSql::editToMySQL()
////{
////	///��
////	int num1 = 39;
////	string name1 = "fd";
////	string query1 = "update ship01 set score=" + to_string(num1) + " where name = " + "'" + name1 + "'";
////	if (mysql_query(this->getConnect(), query1.c_str()) != 0)
////	{
////		cout << mysql_error(this->getConnect()) << endl;
////		mysql_close(this->getConnect());
////		return; // Exit the program with an error code
////	}
////	cout << "�޸ĳɹ�!" << "��ǰ����Ϊ:" << endl;
////	this->findToMySQL();
////}
////
////void MMSql::findToMySQL()
////{
////	//��
//////ͨ��query��ѯ����
////	mysql_query(this->getConnect(), "SELECT * FROM ship01");
////	//ʹ��res�ռ���ѯ��������
////	MYSQL_RES* res = mysql_store_result(this->getConnect());
////	if (!res)
////	{
////		cout << mysql_error(this->getConnect()) << endl;
////		mysql_close(this->getConnect());
////		return; // Exit the program with an error code
////	}
////	//ȡ���ռ��������ݵ�����(���ڱ���)
////	int num_fields = mysql_num_fields(res);
////	//ȡÿһ�е�����,��ӡ
////	MYSQL_ROW row;
////	while ((row = mysql_fetch_row(res)))
////	{
////		for (int i = 0; i < num_fields; i++)
////		{
////			cout << row[i] << " ";
////		}
////		cout << endl;
////	}
////	//�ͷ��ռ�������
////	mysql_free_result(res);
////}
////
////
////int main()
////{
////	MMSql* mysq = new MMSql();
////	mysq->updateID();
////	mysq->addToMySQL();
////	mysq->editToMySQL();
////
////	mysq->delToMySQL();
////
////	cout << "Hello World!\n";
////	return 0;
////}
////
