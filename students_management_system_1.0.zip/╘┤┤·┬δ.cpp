#include<stums.h>
int main() {
	stums instance;
	instance.view();
	return 0;
}